﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CoinPickup : MonoBehaviour {

    public AudioSource coinPickup;
    int d = 0;

    private void OnTriggerEnter2D(Collider2D other) //ce se sprozi trigger
    {
        if (other.CompareTag("Player"))
        {
            d++;
            PlayerPrefs.SetInt("money", PlayerPrefs.GetInt("money")+1); //sharni money
            PlayerPrefs.SetInt("moneyTaIgra", d);
            Destroy(gameObject);
            coinPickup.Play();
        }
    }
}
