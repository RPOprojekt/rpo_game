﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class ENDManeger : MonoBehaviour
{
    public Text yourTime;

    public Text yourCoins;

    void Start()
    {
        float t = PlayerPrefs.GetFloat("koncniCas");

        string minutes = ((int)t / 60).ToString();
        string seconds = ((t % 60).ToString("f0"));

   
       yourTime.text = minutes + ":" + seconds;


        int c = PlayerPrefs.GetInt("moneyTaIgra");

        yourCoins.text = c.ToString();

    }

    public void goToMenu()
    {
        SceneManager.LoadScene("Menu", LoadSceneMode.Single);
    }

}
