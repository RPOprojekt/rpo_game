﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PlayerManeger : MonoBehaviour {

    int firstRun = 0;

    public int currentWeapon = 0;
    public Transform[] weapons; //array za orožja
    public int numWeapons;

    int numTargets;

    public bool spawnkey = false;
    public bool keyobtained = false;

    int stUnicenihTarc=0; //za trgovino (unlock ko vse skupaj unicis 10 tarc)
    public GameObject door;

    public Transform[] characters; //array za orožja
    public int numChar;

    private GameObject stransitioner;//transition v menu

    public GameObject[] levels;
    public int maxLevel = 2;
    public bool konec = false;

    private void Start()
    {
        firstRun = PlayerPrefs.GetInt("savedFirstRun");

        if (firstRun == 0) //ce igra prvic
        {
            PlayerPrefs.SetInt("stevecOdigranihLevelov", 0);
            PlayerPrefs.SetInt("stUnicenihTarc", 0);
            PlayerPrefs.SetFloat("najboljsiCas", 70);
            PlayerPrefs.SetInt("money", 0);

            PlayerPrefs.SetInt("savedFirstRun", PlayerPrefs.GetInt("savedFirstRun")+1);
        }

        stransitioner = GameObject.FindWithTag("ScenTrans");
        spawnkey = false;
        
        numWeapons = weapons.Length;

        SwitchWeapon(currentWeapon);

        if (PlayerPrefs.GetInt("player")==0) //prikazi aktivnega playerja
        {
            characters[0].gameObject.SetActive(true);
            characters[1].gameObject.SetActive(false);
        }
        else if (PlayerPrefs.GetInt("player") == 1)
        {
            characters[1].gameObject.SetActive(true);
            characters[0].gameObject.SetActive(false);
        }
    }

    void Update () {

        numTargets = GameObject.FindGameObjectsWithTag("Tarca").Length; //dobi vse tarce

        if (numTargets == 0 && spawnkey==false) //vse tarce unicene
        {
            stUnicenihTarc = 2;
            spawnkey = true;
            Debug.Log("Unicil si vse tarce spawnal se je kljuc");
        }

        if (numTargets > 0)
        {
            spawnkey = false;
            keyobtained = false;
        }
        if (numTargets == 0 && !GameObject.FindGameObjectWithTag("keyspawnpoint") && keyobtained==false) //Kljuc prejet
        {
            keyobtained = true;
            Debug.Log("Pobral si ključ");
        }

    }

    public void ClickChangeGunButton() //Z klikom na gumb menjas orozje
    {
        currentWeapon++;
        if (currentWeapon==numWeapons) // ce je zadnje orozje gre ob naslednjem kliku na prvega(krozna vrsta)
        {
            currentWeapon = 0;
        }
        SwitchWeapon(currentWeapon);
    }

    void SwitchWeapon(int index)
    {
        
        for (int i=0; i<numWeapons; i++)
        {
            if (index != 0 && i == index && weapons[index].GetComponent<StMetkov>().numBullets != 0) //ce imas orozje pri NE-osnovnem orozju
            {
                Debug.Log("Metki");
                weapons[i].gameObject.SetActive(true);
            }
            else if (index == 0 && i == index) //osnovno orozje ... neomejeno st metkov ... vedno lahko das na true
            {
                weapons[i].gameObject.SetActive(true);
            }
            else if(i == index && weapons[index].GetComponent<StMetkov>().numBullets == 0) //ce pri želenem orozju nimas metkov
            {
                Debug.Log("Nimas metkov");
                currentWeapon = 0;
                weapons[0].gameObject.SetActive(true); //obdrzi osnovno orozje
            }
            if(index!=i) //ostale daj na false
            { 
                weapons[i].gameObject.SetActive(false);
            }
        }
    }

    public void SwitchLevel()
    {
        Debug.Log("SWITCH_LEVEL... stevecVrat = "+PlayerPrefs.GetInt("stevecOdprtihVrat"));

        if (PlayerPrefs.GetInt("stevecOdprtihVrat") + 1 <= maxLevel) //ce se nismo koncali zadnjega levela
        {
            levels[PlayerPrefs.GetInt("stevecOdprtihVrat")-1].gameObject.SetActive(false); //ta level na false
            levels[PlayerPrefs.GetInt("stevecOdprtihVrat")].gameObject.SetActive(true); //naslednji level na true
        }
        else // koncali smo zadnji level
        {
            PlayerPrefs.SetInt("stevecOdprtihVrat", 0); //stevec nazaj na 0

            if (door.GetComponent<DoorOpen>().doorsopen == true)
            {
                PlayerPrefs.SetInt("stevecOdigranihLevelov", PlayerPrefs.GetInt("stevecOdigranihLevelov") + 1); //shranjuje st koncanih levelov
            }

            konec = true;
            stransitioner.GetComponent<SceneTransition>().TransitionToScene(3); // gre v END GAME 
        }
    }

    public void ExitGame()
    {
        for(int i=0; i<numWeapons; i++)
        {
            PlayerPrefs.SetInt("bulets"+weapons[i].name, 0); //na koncu igre so vsi metki 0
        }

        if (door.GetComponent<DoorOpen>().doorsopen == true)
        {
            PlayerPrefs.SetInt("stevecOdigranihLevelov", PlayerPrefs.GetInt("stevecOdigranihLevelov") + 1); //shranjuje st koncanih levelov
        }
        stransitioner.GetComponent<SceneTransition>().TransitionToScene(0); //gre v meni
        //SceneManager.LoadScene("Menu"); //gre v meni

        PlayerPrefs.SetInt("stevecOdprtihVrat", 0); //stevec vrat nazaj na 0

        Debug.Log("stevecLevelov: "+PlayerPrefs.GetInt("stevecOdigranihLevelov")+ "  stevecUnicenihTarc: "+ PlayerPrefs.GetInt("stUnicenihTarc")+ " stevecOdprtihVrat:"+ PlayerPrefs.GetInt("stevecOdprtihVrat"));
    }


    IEnumerator Wait()
    {
            yield return new WaitForSeconds(3.0f);      
    }


}
