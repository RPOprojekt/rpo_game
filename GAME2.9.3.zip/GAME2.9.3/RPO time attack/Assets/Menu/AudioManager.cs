﻿using UnityEngine.Audio;
using UnityEngine;
using System;


public class AudioManager : MonoBehaviour
{

    public Sound[] sounds;
    public static AudioManager instance;
    void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }
        else
        {
            Destroy(gameObject);
            return;
        }

        DontDestroyOnLoad(gameObject);
        foreach (Sound s in sounds)
        {
            s.source = gameObject.AddComponent<AudioSource>();
            s.source.clip = s.clip;

            s.source.volume = s.volume;
            s.source.pitch = s.pitch;
            s.source.loop = s.loop;
        }
    }
    void Start()
    {
        Play("Theme");
    }
    public void Play(string name)
    {
        Sound s = Array.Find(sounds, sound => sound.name == name);    //poisce zvok s tem imenom v arr sounds
        if (sounds == null)
        {
            Debug.LogWarning("ERROR: Sound" + name + "not found!");
            return;
        }
        s.source.Play();
    }

    void Quit()
    {

    }
}

//FindObjectOfType<AudioManager>().Play("imezvokaizUnity");   //toto kodo prilepi v scripto kje hoces da ti svira